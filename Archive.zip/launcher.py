"""
launcher.py – entry point for the packaged .exe
Starts the Streamlit server, opens the browser, adds a system tray icon,
and shuts down cleanly when the browser tab is closed.
"""
import sys
import os
import threading
import webbrowser
import time
from http.server import BaseHTTPRequestHandler, HTTPServer


def resource_path(relative_path):
    if hasattr(sys, "_MEIPASS"):
        return os.path.join(sys._MEIPASS, relative_path)
    return os.path.join(os.path.dirname(os.path.abspath(__file__)), relative_path)


def open_browser():
    time.sleep(4)
    webbrowser.open("http://localhost:8501")


class ShutdownHandler(BaseHTTPRequestHandler):
    def do_POST(self):
        if self.path == "/shutdown_app":
            self.send_response(200)
            self.end_headers()
            threading.Thread(target=self._delayed_exit, daemon=True).start()

    def _delayed_exit(self):
        time.sleep(1)
        os._exit(0)

    def log_message(self, format, *args):
        pass  # Suppress HTTP log output


def run_shutdown_listener():
    """Listen on port 8502 for shutdown signal from browser."""
    try:
        server = HTTPServer(("localhost", 8502), ShutdownHandler)
        server.serve_forever()
    except Exception:
        pass


def run_tray():
    """Show a system tray icon with Open and Quit options."""
    try:
        import pystray
        from PIL import Image, ImageDraw

        img = Image.new("RGB", (64, 64), color=(255, 255, 255))
        draw = ImageDraw.Draw(img)
        draw.ellipse([8, 8, 56, 56], fill=(46, 139, 87))

        def on_open(icon, item):
            webbrowser.open("http://localhost:8501")

        def on_quit(icon, item):
            icon.stop()
            os._exit(0)

        menu = pystray.Menu(
            pystray.MenuItem("Open App", on_open),
            pystray.MenuItem("Quit", on_quit),
        )

        icon = pystray.Icon("GEP Tool", img, "GEP Package Tool", menu)
        icon.run()

    except Exception:
        while True:
            time.sleep(60)


def main():
    if hasattr(sys, "_MEIPASS"):
        os.chdir(os.path.dirname(sys.executable))

    app_script = resource_path("automationtoolstreamlit19.py")

    os.environ["STREAMLIT_SERVER_PORT"] = "8501"
    os.environ["STREAMLIT_SERVER_HEADLESS"] = "true"
    os.environ["STREAMLIT_BROWSER_GATHER_USAGE_STATS"] = "false"
    os.environ["STREAMLIT_GLOBAL_DEVELOPMENT_MODE"] = "false"

    # Open browser
    threading.Thread(target=open_browser, daemon=True).start()

    # System tray
    threading.Thread(target=run_tray, daemon=True).start()

    # Shutdown listener (port 8502)
    threading.Thread(target=run_shutdown_listener, daemon=True).start()

    from streamlit.web import cli as stcli
    sys.argv = ["streamlit", "run", app_script]
    sys.exit(stcli.main())


if __name__ == "__main__":
    main()
