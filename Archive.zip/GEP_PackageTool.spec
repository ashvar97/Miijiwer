# -*- mode: python ; coding: utf-8 -*-
import sys
from PyInstaller.utils.hooks import collect_data_files, collect_submodules, copy_metadata

streamlit_datas = collect_data_files("streamlit", include_py_files=True)

meta_datas = (
    copy_metadata("streamlit")
    + copy_metadata("pandas")
    + copy_metadata("openpyxl")
    + copy_metadata("altair")
    + copy_metadata("packaging")
    + copy_metadata("pystray")
    + copy_metadata("pillow")
)

app_datas = [
    ("automationtoolstreamlit19.py", "."),
]

all_datas = streamlit_datas + app_datas + meta_datas

hidden_imports = (
    collect_submodules("streamlit")
    + collect_submodules("altair")
    + collect_submodules("pystray")
    + collect_submodules("PIL")
    + [
        "streamlit.web.cli",
        "streamlit.runtime.scriptrunner.magic_funcs",
        "pandas",
        "openpyxl",
        "difflib",
        "pkg_resources.py2_warn",
        "packaging",
        "packaging.version",
        "packaging.specifiers",
        "packaging.requirements",
        "pystray",
        "PIL",
        "PIL.Image",
        "PIL.ImageDraw",
    ]
)

block_cipher = None

a = Analysis(
    ["launcher.py"],
    pathex=["."],
    binaries=[],
    datas=all_datas,
    hiddenimports=hidden_imports,
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[],
    win_no_prefer_redirects=False,
    win_private_assemblies=False,
    cipher=block_cipher,
    noarchive=False,
)

pyz = PYZ(a.pure, a.zipped_data, cipher=block_cipher)

exe = EXE(
    pyz,
    a.scripts,
    [],
    exclude_binaries=True,
    name="GEP_PackageTool",
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    console=False,              # No console window — clean UX
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
)

coll = COLLECT(
    exe,
    a.binaries,
    a.zipfiles,
    a.datas,
    strip=False,
    upx=True,
    upx_exclude=[],
    name="GEP_PackageTool",
)
