import os
import re
import shutil
from dataclasses import dataclass
from typing import List, Set, Tuple, Dict, Optional

from difflib import SequenceMatcher

import pandas as pd
import streamlit as st
import streamlit.components.v1 as components

# ========= SETTINGS YOU MAY CHANGE =========
MDL_FILE = "Test.xlsx"

# Column indices in MDL (0-based)
COL_H1 = 0
COL_H2 = 1
COL_H3 = 2
COL_DOCNAME = 3
COL_FILTER = 4
COL_PACKTYPE = 5
COL_FILETYPE = 6
COL_DOCTYPE = 7

IGNORED_SHEETS = {
    "GEP - Cover Page",
    "Revision_history",
    "Instructions",
}

# No search/show-all, so cap the component list to keep UI usable
MAX_COMPONENT_OPTIONS_PER_SHEET = 250

# Sidebar rendering limit
SIDEBAR_COMPONENTS_RENDER = 120

# Fuzzy matching strictness (higher = safer, but may miss more)
FUZZY_CUTOFF = 0.92


# ========= DATA MODEL =========
@dataclass
class MDLEntry:
    kind: str
    product: str
    rel_path: str
    filter_comp: str
    pack_type: str
    file_type: str
    doc_type: str


@dataclass
class ParsedMDL:
    entries: List[MDLEntry]
    products: Set[str]
    package_types: Set[str]


# ========= FUZZY MATCH HELPERS =========
def _norm(name: str) -> str:
    """
    Normalize names to be tolerant to:
    - case differences
    - whitespace differences
    - '_' '-' differences
    """
    s = name.strip().lower()
    s = re.sub(r"\s+", "", s)
    s = s.replace("_", "").replace("-", "")
    return s


def _similarity(a: str, b: str) -> float:
    return SequenceMatcher(None, _norm(a), _norm(b)).ratio()


def _best_match(target: str, candidates: List[str]) -> Tuple[Optional[str], float]:
    if not candidates:
        return None, 0.0

    best_name = None
    best_score = 0.0
    for c in candidates:
        score = _similarity(target, c)
        if score > best_score:
            best_score = score
            best_name = c
    return best_name, best_score


def resolve_path_fuzzy(repo_root: str, rel_path: str, cutoff: float = FUZZY_CUTOFF) -> Optional[str]:
    """
    Resolve a rel_path inside repo_root using fuzzy matching per path component.

    Example:
      rel_path = "Sheet/01_Folder/02_Sub/file.pdf"

    We walk step-by-step:
      repo_root -> best match for "Sheet" -> best match for "01_Folder" -> ...
    """
    # MDL uses "/" to join parts; handle Windows too just in case
    parts = [p for p in rel_path.replace("\\", "/").split("/") if p]
    current = repo_root

    # Cache listings for speed
    dir_cache: Dict[str, List[str]] = {}

    for i, part in enumerate(parts):
        if not os.path.isdir(current):
            return None

        if current not in dir_cache:
            try:
                dir_cache[current] = os.listdir(current)
            except OSError:
                return None

        candidates = dir_cache[current]

        best, score = _best_match(part, candidates)
        if best is None or score < cutoff:
            return None

        current = os.path.join(current, best)

    return current


# ========= PARSE MDL EXCEL =========
def parse_mdl(path: str) -> ParsedMDL:
    if not os.path.exists(path):
        st.error(f"MDL file '{path}' not found in: {os.getcwd()}")
        st.stop()

    xls = pd.ExcelFile(path)

    entries: List[MDLEntry] = []
    products: Set[str] = set()
    package_types: Set[str] = set()

    for sheet_name in xls.sheet_names:
        if sheet_name in IGNORED_SHEETS:
            continue

        df = pd.read_excel(xls, sheet_name=sheet_name, header=None)

        needed_cols = [COL_H1, COL_H2, COL_H3, COL_DOCNAME, COL_FILTER, COL_PACKTYPE, COL_FILETYPE]
        if df.shape[1] <= max(needed_cols):
            continue

        products.add(sheet_name)

        current_h1 = ""
        current_h2 = ""
        current_h3 = ""

        for _, row in df.iterrows():
            if len(row) <= COL_FILETYPE:
                continue

            file_type_val = row[COL_FILETYPE]
            if pd.isna(file_type_val):
                continue

            file_type = str(file_type_val).strip()
            if file_type == "File Type":
                continue

            docname_val = row[COL_DOCNAME]
            docname = "" if pd.isna(docname_val) else str(docname_val).strip()

            filter_val = row[COL_FILTER]
            filter_str = "" if pd.isna(filter_val) else str(filter_val).strip()

            pack_val = row[COL_PACKTYPE]
            pack_str = "" if pd.isna(pack_val) else str(pack_val).strip()

            doc_type = ""
            if len(row) > COL_DOCTYPE:
                doc_type_val = row[COL_DOCTYPE]
                if not pd.isna(doc_type_val):
                    doc_type = str(doc_type_val).strip()

            if pack_str:
                package_types.add(pack_str)

            # Directories
            if file_type == "Directory":
                h1 = row[COL_H1]
                h2 = row[COL_H2]
                h3 = row[COL_H3]

                if not pd.isna(h1):
                    try:
                        n1 = int(h1)
                        current_h1 = f"{n1:02d}_{docname}"
                        current_h2 = ""
                        current_h3 = ""
                    except ValueError:
                        continue
                elif not pd.isna(h2):
                    try:
                        n2 = int(h2)
                        current_h2 = f"{n2:02d}_{docname}"
                        current_h3 = ""
                    except ValueError:
                        continue
                elif not pd.isna(h3):
                    try:
                        n3 = int(h3)
                        current_h3 = f"{n3:02d}_{docname}"
                    except ValueError:
                        continue

                parts = [sheet_name, current_h1, current_h2, current_h3]
                parts = [p for p in parts if p]
                if not parts:
                    continue

                rel_path = "/".join(parts)
                entries.append(
                    MDLEntry(
                        kind="Directory",
                        product=sheet_name,
                        rel_path=rel_path,
                        filter_comp=filter_str,
                        pack_type=pack_str,
                        file_type=file_type,
                        doc_type=doc_type,
                    )
                )

            # Files
            elif file_type == "File":
                if not docname:
                    continue

                parts = [sheet_name, current_h1, current_h2, current_h3, docname]
                parts = [p for p in parts if p]
                rel_path = "/".join(parts)

                entries.append(
                    MDLEntry(
                        kind="File",
                        product=sheet_name,
                        rel_path=rel_path,
                        filter_comp=filter_str,
                        pack_type=pack_str,
                        file_type=file_type,
                        doc_type=doc_type,
                    )
                )

    return ParsedMDL(entries=entries, products=products, package_types=package_types)


# ========= HELPERS (NO packtype filtering here) =========
def components_for_product(entries: List[MDLEntry], product: str) -> List[str]:
    comps = {e.filter_comp for e in entries if e.product == product and e.filter_comp}
    comps_sorted = sorted(comps, key=lambda x: x.lower())
    if len(comps_sorted) > MAX_COMPONENT_OPTIONS_PER_SHEET:
        comps_sorted = comps_sorted[:MAX_COMPONENT_OPTIONS_PER_SHEET]
    return comps_sorted


def component_to_products_map(entries: List[MDLEntry]) -> Dict[str, Set[str]]:
    m: Dict[str, Set[str]] = {}
    for e in entries:
        if not e.filter_comp:
            continue
        m.setdefault(e.filter_comp, set()).add(e.product)
    return m


# ========= COPY LOGIC =========
def entry_matches(entry: MDLEntry, selected_products: Set[str], selected_components: Set[str], selected_packtypes: Set[str]) -> bool:
    if selected_products and entry.product not in selected_products:
        return False
    if selected_packtypes and entry.pack_type not in selected_packtypes:
        return False
    if selected_components and entry.filter_comp not in selected_components:
        return False
    return True


def build_package(
    parsed: ParsedMDL,
    repo_root: str,
    output_root: str,
    selected_products: Set[str],
    selected_components: Set[str],
    selected_packtypes: Set[str],
) -> Tuple[int, List[str]]:
    copied = 0
    missing: List[str] = []

    for entry in parsed.entries:
        if not entry_matches(entry, selected_products, selected_components, selected_packtypes):
            continue

        # Destination path always based on MDL structure
        dst = os.path.join(output_root, entry.rel_path)

        # 1) Try exact source first (fast path)
        exact_src = os.path.join(repo_root, entry.rel_path)
        src_to_use: Optional[str] = None

        if entry.kind == "Directory":
            # Create destination directory always (even if source mismatched)
            os.makedirs(dst, exist_ok=True)

            # Validate source directory: exact then fuzzy
            if os.path.isdir(exact_src):
                src_to_use = exact_src
            else:
                src_to_use = resolve_path_fuzzy(repo_root, entry.rel_path, cutoff=FUZZY_CUTOFF)

            if not src_to_use or not os.path.isdir(src_to_use):
                missing.append(exact_src)

        else:
            # File copy: exact then fuzzy
            if os.path.isfile(exact_src):
                src_to_use = exact_src
            else:
                src_to_use = resolve_path_fuzzy(repo_root, entry.rel_path, cutoff=FUZZY_CUTOFF)

            if src_to_use and os.path.isfile(src_to_use):
                os.makedirs(os.path.dirname(dst), exist_ok=True)
                shutil.copy2(src_to_use, dst)
                copied += 1
            else:
                missing.append(exact_src)

    return copied, missing


# ========= STATE =========
def init_state():
    if "selected_packtypes" not in st.session_state:
        st.session_state.selected_packtypes = set()
    if "selected_components" not in st.session_state:
        st.session_state.selected_components = set()


def clear_all():
    st.session_state.selected_packtypes = set()
    st.session_state.selected_components = set()


# ========= APP =========
def main():
    st.set_page_config(page_title="GEP Package Automation Tool", layout="wide")

    # Inject heartbeat: when browser tab closes, call shutdown listener on port 8502
    components.html("""
        <script>
        window.addEventListener('beforeunload', function() {
            fetch('http://localhost:8502/shutdown_app', {method: 'POST', keepalive: true});
        });
        </script>
    """, height=0)

    init_state()

    st.title("GEP Package Automation Tool")

    parsed = parse_mdl(MDL_FILE)
    comp_to_products = component_to_products_map(parsed.entries)

    # ---- Sidebar: Review ----
    with st.sidebar:
        st.header("Review")

        pt_count = len(st.session_state.selected_packtypes)
        with st.expander(f"Package type ({pt_count})", expanded=False):
            if pt_count:
                for p in sorted(st.session_state.selected_packtypes):
                    st.write(f"• {p}")
            else:
                st.caption("None selected (means ALL package types at build time).")

        selected_list = sorted(st.session_state.selected_components, key=lambda x: x.lower())
        comp_count = len(selected_list)

        with st.expander(f"Components selected ({comp_count})", expanded=False):
            if not selected_list:
                st.caption("No components selected yet.")
            else:
                st.caption("Click ✕ to remove:")
                to_show = selected_list[:SIDEBAR_COMPONENTS_RENDER]

                for comp in to_show:
                    row = st.columns([12, 1])
                    with row[0]:
                        st.write(comp)
                    with row[1]:
                        if st.button("✕", key=f"rm_{comp}", help="Remove"):
                            st.session_state.selected_components.discard(comp)
                            st.rerun()

                if comp_count > SIDEBAR_COMPONENTS_RENDER:
                    st.caption(f"Showing first {SIDEBAR_COMPONENTS_RENDER}.")

        st.markdown("---")
        if st.button("🧹 Clear all", use_container_width=True):
            clear_all()
            st.rerun()

    # ---- Main content ----
    top = st.container(border=True)
    mid = st.container(border=True)
    bottom = st.container(border=True)

    with top:
        st.subheader("Package Type selection ")

        selected_packtypes = st.multiselect(
            "Package Type (Preliminary, Permitting or Operational)",
            options=sorted(parsed.package_types),
            default=sorted(st.session_state.selected_packtypes),
            help="Independent selection. Component options will NOT change based on this.",
        )
        st.session_state.selected_packtypes = set(selected_packtypes)

        st.caption(f"Fuzzy matching cutoff: {FUZZY_CUTOFF} (higher = safer)")

    with mid:
        st.subheader("Add components")

        col1, col2 = st.columns([1, 2])
        with col1:
            pick_product = st.selectbox("Product Type", options=sorted(parsed.products))

        with col2:
            options = components_for_product(parsed.entries, pick_product)

            if not options:
                st.warning("No components found for this sheet.")
            else:
                if len(options) >= MAX_COMPONENT_OPTIONS_PER_SHEET:
                    st.caption(f"Showing first {MAX_COMPONENT_OPTIONS_PER_SHEET} options (alphabetical).")

                with st.form("add_components_form", clear_on_submit=True):
                    temp_components = st.multiselect(f"Components in {pick_product}", options=options)
                    submitted = st.form_submit_button("➕ Add selected components")

                    if submitted:
                        for c in temp_components:
                            st.session_state.selected_components.add(c)
                        st.success(f"Added {len(temp_components)} component(s).")
                        st.rerun()

    with bottom:
        st.subheader("Build package")

        repo_root = st.text_input("Repository root", value="", placeholder=r"Path to your repository root folder")
        output_root = st.text_input("Output folder (package destination)", value="", placeholder=r"Example: C:\Project\Package_Output")

        if st.button("📥 Build Package", type="primary"):
            if not st.session_state.selected_components:
                st.error("Please select at least one component.")
                return
            if not repo_root or not os.path.isdir(repo_root):
                st.error("Please enter a valid existing repository root folder.")
                return
            if not output_root:
                st.error("Please enter a valid output folder path.")
                return

            os.makedirs(output_root, exist_ok=True)

            # Products derived from selected components (independent of pack type)
            selected_products: Set[str] = set()
            for comp in st.session_state.selected_components:
                selected_products.update(comp_to_products.get(comp, set()))

            with st.spinner("Copying files and creating package."):
                copied, missing = build_package(
                    parsed=parsed,
                    repo_root=repo_root,
                    output_root=output_root,
                    selected_products=selected_products,
                    selected_components=st.session_state.selected_components,
                    selected_packtypes=st.session_state.selected_packtypes,
                )

            st.success(f"Done! Copied **{copied}** file(s).")
            st.info(f"Package location: `{os.path.abspath(output_root)}`")

            if missing:
                st.warning(f"{len(missing)} paths were referenced in MDL but not found (even with fuzzy match).")
                with st.expander("Show missing paths"):
                    for p in missing[:300]:
                        st.write(p)
                    if len(missing) > 300:
                        st.caption(f"Showing first 300 of {len(missing)}.")


if __name__ == "__main__":
    main()
