@echo off
echo.
echo ============================================================
echo  GEP Package Automation Tool – EXE Builder
echo ============================================================
echo.

where python >nul 2>&1
if errorlevel 1 (
    echo [ERROR] Python not found.
    pause
    exit /b 1
)

echo [Step 1/3] Installing dependencies...
python -m pip install --upgrade pyinstaller streamlit pandas openpyxl pystray pillow
if errorlevel 1 (
    echo [ERROR] pip install failed.
    pause
    exit /b 1
)

echo.
echo [Step 2/3] Running PyInstaller...
python -m PyInstaller GEP_PackageTool.spec --clean --noconfirm
if errorlevel 1 (
    echo [ERROR] PyInstaller build failed.
    pause
    exit /b 1
)

echo.
echo [Step 3/3] Copying Test.xlsx...
if exist "Test.xlsx" (
    copy /Y "Test.xlsx" "dist\GEP_PackageTool\Test.xlsx"
    echo   Copied Test.xlsx successfully.
) else (
    echo   [WARNING] Test.xlsx not found. Copy it manually into dist\GEP_PackageTool\
)

echo.
echo ============================================================
echo  BUILD COMPLETE!
echo  Your application is in:  dist\GEP_PackageTool\
echo  Launch it by running:    dist\GEP_PackageTool\GEP_PackageTool.exe
echo ============================================================
echo.
pause
